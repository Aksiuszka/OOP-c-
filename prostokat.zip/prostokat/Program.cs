﻿using System;

namespace prostokat
{
    class Program
    {
        public class Rectangle
        {
            private double width;
            private double length;
            
            public Rectangle(double width, double length)
            {
                this.width = width;
                this.length = length;
            }
            private double Area()
            {
                return width * length;
            }
            private double Perimeter()
            {
                return (2 * width) + (2 * length);
            }
            public void Display()
            {
                Console.WriteLine($"Hello, prostokąt ma taką powierzchnię {Area()} i taki obwód {Perimeter()}");
            }
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Dzialam!!!");
            Rectangle rectangle = new Rectangle(3, 4);
            rectangle.Display();
        }
    }
}
