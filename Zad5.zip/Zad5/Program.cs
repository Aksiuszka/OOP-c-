﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;





public class Lista

{

    private List<int> liczby; //przechowywane beda cyfry;

    private int pojemnosc; //maksymalna liczba elementów, możliwych do przechowywania,

    private int rozmiar; //aktualna liczba przechowywanych elementów




    public Lista(int pojemnosc)
    {

        this.pojemnosc = pojemnosc;

        this.liczby = new List<int>(pojemnosc);

        this.rozmiar = RozmiarTablicy();

    }

    private int RozmiarTablicy()
    {

        return liczby.Count;

    }

    public void dodajElement(int element)
    {
        rozmiar = RozmiarTablicy();

        if (rozmiar == pojemnosc)
        {

            Console.WriteLine("Błąd! Nie ma więcej miejsca!");

        }
        else
        {

            liczby.Add(element);

            Console.WriteLine("Element dodano do tablicy");

        }

    }

    public void znajdz(int szukanaLiczba)
    {

        for (int i = 0; i < liczby.Count; i++)
        {

            if (liczby[i] == szukanaLiczba)
            {

                Console.WriteLine("Bingo! Znaleziono szukana " + szukanaLiczba);

            }

            else
            {

                Console.WriteLine("-1");

            }

        }

    }

    public void wypisz()
    {

        Console.WriteLine("Rozmar tablicy to " + rozmiar);

        Console.WriteLine("Pojemnosc to tablicy to " + pojemnosc);

        Console.WriteLine("elementy tablicy to ");

        for (int i = 0; i < liczby.Count; i++)
        {

            Console.WriteLine(liczby[i]);

        }

    }

    public void usunPierwszy()
    {

        Console.WriteLine("Lista zmniejszona o 1 element");

        liczby.RemoveAt(0);

        Console.WriteLine("elementy tablicy to ");

        for (int i = 0; i < liczby.Count; i++)
        {

            Console.WriteLine(liczby[i]);

        }

    }



    public void usunPowtorzenia()
    {

        Console.WriteLine("Lista zmniejszona o powtorzenia");

        for (int i = 0; i < liczby.Count; i++)
        {

            for (int j = 1; j <= liczby.Count - 1; j++)
            {

                if (liczby[i] == liczby[j])
                {

                    liczby.RemoveAt(0);

                }

            }

        }
        foreach (var item in liczby)
        {

            Console.Write(item + ", ");

        }

    }

    public void odwroc()
    {

        Console.WriteLine("Odwracam tablice");

        liczby.Reverse();

        Console.WriteLine("Odwrocona tablica to");

        foreach (var item in liczby)
        {

            Console.Write(item + ", ");

        }



    }

    public void zapisz(string zapisajka)
    {

        Console.WriteLine("Zapisuje");

        string path = @$"{AppDomain.CurrentDomain.BaseDirectory}\{zapisajka}.txt";

        using (StreamWriter zapisywacz = File.CreateText(path))
        {

            foreach (var item in liczby)
            {

                zapisywacz.WriteLine(item);

            }

        }





    }

}
internal class Program
{
    static void Main(string[] args)
    {
        Lista lista = new Lista(18);
        lista.dodajElement(9);
        lista.dodajElement(2);
        lista.dodajElement(3);
        lista.dodajElement(1);
        lista.dodajElement(3);
        lista.dodajElement(1);
        Console.WriteLine("Wypisuje dane");
        lista.wypisz();
        Console.WriteLine("znajduje element" );
        lista.znajdz(100);
        
    
       
        Console.WriteLine("Usuwa 1 element");
        lista.usunPierwszy();
        Console.WriteLine("odwraca");
        lista.odwroc();

        Console.WriteLine("usuwa powtorzenia");
        lista.usunPowtorzenia();
        Console.WriteLine("zapisuje");
        lista.zapisz("1234");

    }
}


